Curso: K3522
Numero de Grupo: 31
Integrantes: - Juan Cruz Andreacchio 209.709-6 
             - Matías Dopazo 208.965-8 
             - Ignacio Pereda 208.794-7 
             - Nicolás Longo 208.052-7 
Email del responsable: juan.andreacchio@gmail.com